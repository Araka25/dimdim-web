export default function AccountsPage() {
  return (
    <section className="space-y-2">
      <h1 className="text-2xl font-semibold">Contas</h1>
      <p className="text-sm text-white/60">Próximo: criar tabela accounts e CRUD.</p>
    </section>
  );
}
