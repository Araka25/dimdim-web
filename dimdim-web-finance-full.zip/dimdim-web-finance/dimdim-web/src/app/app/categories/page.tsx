export default function CategoriesPage() {
  return (
    <section className="space-y-2">
      <h1 className="text-2xl font-semibold">Categorias</h1>
      <p className="text-sm text-white/60">Próximo: criar tabela categories e CRUD.</p>
    </section>
  );
}
